
public interface IntToGenericInterfaceInt {

    public int getCount( );
      
    public int getCapacity( );
        
    public void add( int newInt ) throws IllegalArgumentException;
    
    public int get( int index ) throws IllegalArgumentException;
    
    public String toString( );

    public boolean equals( Object o );
   

    

    
    
    
    
    
    
    
    
    
    
    
    
    
}
