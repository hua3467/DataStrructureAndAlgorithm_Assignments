
public interface Comparator <K> {
    
    int compare( K a, K b );
}
